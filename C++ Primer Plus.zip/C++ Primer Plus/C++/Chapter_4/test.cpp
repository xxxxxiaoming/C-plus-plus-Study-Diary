#include <iostream>

int main()
{
	using namespace std;
	int p[2]={1,2};
	p=p+1;
	cout<<*p;
	return 0;
}