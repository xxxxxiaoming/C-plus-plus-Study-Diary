#include <iostream>

int main()
{
	using namespace std;

	float gallons_i;
	float miles_i;
	float miles_per_gallon;

	cout<<"Enter the miles you have driven: ";
	cin>>miles_i;
	cout<<"Enter the gallons you have used: ";
	cin>>gallons_i;

	miles_per_gallon=miles_i/gallons_i;

	cout<<"Your cars has gotten "<<miles_per_gallon<<" miles per gallon.\n";

	return 0;
}