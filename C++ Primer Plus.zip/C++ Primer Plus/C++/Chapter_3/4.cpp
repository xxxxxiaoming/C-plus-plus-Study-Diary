#include <iostream>

int main()
{
	using namespace std;

	const long trans_s2d=3600*24;
	const int trans_s2h=3600;
	const int trans_s2m=60;
	long secs_i;
	int days_o;
	int hors_o;
	int mins_o;
	int secs_o;

	cout<<"Enter the number of seconds: ";
	cin>>secs_i;

	days_o=secs_i/trans_s2d;
	hors_o=secs_i%trans_s2d/trans_s2h;
	mins_o=secs_i%trans_s2d%trans_s2h/trans_s2m;
	secs_o=secs_i%trans_s2d%trans_s2h%trans_s2m;

	cout<<secs_i<<" seconds = "<<days_o<<" days "<<hors_o<<" hours "<<mins_o<<" minutes "<<secs_o<<" seconds\n";

	return 0;
}