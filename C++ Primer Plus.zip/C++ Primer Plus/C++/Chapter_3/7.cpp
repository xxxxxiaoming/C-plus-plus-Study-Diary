#include <iostream>

int main()
{
	using namespace std;

	const float trans_l2g=3.875f;
	const float dis_miles=62.14f;
	float consumption_i;
	float cons_gallons;
	float consumption_o;
	
	cout<<"Enter the consumtion in the European style(l/100km): ";
	cin>>consumption_i;
	
	cons_gallons=consumption_i/trans_l2g;
	consumption_o=dis_miles/cons_gallons;

	cout<<"The consumption in American style is "<<consumption_o<<" mpg.\n";

	return 0;
}