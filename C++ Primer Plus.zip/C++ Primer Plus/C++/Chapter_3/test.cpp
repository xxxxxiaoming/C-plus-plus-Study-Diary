#include<iostream>
//#include<limits.h>
//#include<float.h>
int main()
{
	using namespace std;
	//cout.setf(ios_base::fixed,ios_base::floatfield);
	float a=0.2254f;
	//double b=2.111227333;
	a=a*a;
	cout<<a;
	return 0;
}