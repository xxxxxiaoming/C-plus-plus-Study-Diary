#include <iostream>

int main()
{
	using namespace std;

	long popult_w;
	long popult_us;
	float percent;

	cout<<"Enter the world's population: ";
	cin>>popult_w;
	cout<<"Enter the population of the U.S: ";
	cin>>popult_us;

	percent=double (popult_us)/double (popult_w)*100;

	cout<<"The population of the U.S is "<<percent<<" % of the world population.\n";

	return 0;
}