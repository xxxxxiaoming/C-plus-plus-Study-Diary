#include <iostream>

int main()
{
	using namespace std;

	const float trans_m2d=60;
	const float trans_s2d=3600;
	int deg_i;
	int min_i;
	int sec_i;
	float deg_o;

	cout<<"Enter a latitude in degrees, minutes and seconds:\n";
	cout<<"First, enter the degrees: ";
	cin>>deg_i;
	cout<<"Next, enter the minutes of arc: ";
	cin>>min_i;
	cout<<"Finally, enter the seconds of arc: ";
	cin>>sec_i;

	deg_o=deg_i+min_i/trans_m2d+sec_i/trans_s2d;

	cout<<deg_i<<" degrees, "<<min_i<<" minutes, "<<sec_i<<" seconds = "<<deg_o<<" degrees\n";

	return 0;
}