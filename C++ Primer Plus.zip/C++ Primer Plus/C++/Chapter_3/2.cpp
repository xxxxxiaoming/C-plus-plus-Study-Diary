#include <iostream>

int main()
{
	using namespace std;

	const int trans_ft=12;
	const float trans_ic=0.0254f;
	const float trans_kg=2.2f;

	int height_i_ft;
	int height_i_ic;
	int weight_i_lbs;
	float height_m;
	float weight_kg;
	double bmi;

	cout<<"Please enter your heignt(ft+ic) and weight(lbs):_____\b\b\b\b\b";
	cin>>height_i_ft;
	cin>>height_i_ic;
	cin>>weight_i_lbs;

	height_m=(height_i_ft*trans_ft+height_i_ic)*trans_ic;
	weight_kg=weight_i_lbs/trans_kg;
	bmi=weight_kg/(height_m*height_m);

	cout<<"Your bmi is: "<<bmi<<endl;

	return 0;
}